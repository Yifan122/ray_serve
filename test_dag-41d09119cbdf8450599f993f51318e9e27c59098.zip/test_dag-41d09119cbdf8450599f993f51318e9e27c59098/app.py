from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.applications import Starlette
from typing import Dict, List


async def app_endpoint(request: Request):
    l = await request.json()
    print(l)
    print(type(l))
    print(l["0"])



    # Accessing request method (GET, POST, etc.)
    method = request.method

    # Accessing path parameters
    path_params = request.path_params

    # Accessing query parameters
    query_params = request.query_params

    # Accessing request headers
    headers = request.headers

    # Accessing JSON data from request body
    json_data = await request.json()

    return JSONResponse({'method': method, 'path_params': path_params,
                         'query_params': dict(query_params), 'headers': dict(headers),
                         'json_data': json_data})

app = Starlette(debug=True, routes=[Route('/', app_endpoint, methods=['POST'])])
